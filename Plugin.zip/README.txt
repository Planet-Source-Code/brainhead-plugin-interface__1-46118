You may use this for free.
All what I ask is that if you change something in the code, let me know! I want to improve this project.
An other thing is that if you use it, please at my name in the aboutscreen and place this dll (if posible)
in the map c:\windows\system32\boven  the reasan is that my programs that use this dll will place it also in that map and this
way there will not be the same dll over and over again (and the dll wil be back compatible if posible ofcours)

Tim Boven
timboven@hotmail.com